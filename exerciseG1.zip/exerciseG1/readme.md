COMP3811 Exercise G.1
=====================

Base project for Exercise G.1 in COMP3811. Do not re-distribute outside of
Minerva.

